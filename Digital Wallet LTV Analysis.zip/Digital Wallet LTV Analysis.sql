##-----------------------SQL PROJECT -4 ---------CUSTOMER LTV ANALYSIS-----------------------------------------------------------------------------------------------------------
## --------------------Before every With Statement select1; has been applied to avoid any Parsing issue---------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
## 1. Identify customers who spend more than the average customer but have fewer active days than the average.
select customer_id,total_spent,active_days,
(select avg(total_spent) from customers)as Total_avg,
(select avg(active_days)from customers)as Total_avg_days
from customers
where total_spent > (
select avg(total_spent)as Total_Avg from customers)and 
active_days < (
select avg(active_days)from customers);
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

## 2. Find the top customers in each income level based on lifetime value and show how much higher they are compared to others in the same group.
select customer_id,income_level,ltv,
dense_rank()over(partition by income_level order by ltv desc)as Ltv_Rank,
coalesce(lag(ltv) over (partition by income_level ),"-")as Prv
From customers;

select *,
case 
when prv is null then "	-"
else cast(prv-ltv as char)
end as diff
from (
select customer_id,income_level,ltv,
dense_rank()over(partition by income_level order by ltv desc)as Ltv_Rank,
lag(ltv) over (partition by income_level )as Prv
From customers)t;
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

## 3. Determine which age group contributes the highest total spend within each location.
select 1;

with high_rank as (
select Location,age,total_spent,
dense_rank()over(partition by location order  by total_spent desc)as spent_rank
from (
select location,age, round(sum(total_spent),2)as Total_spent
from customers
group by location,age)t)
select Location,age,total_spent
from high_rank
where spent_rank =1
order by total_spent desc;
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

## 4. Identify customers whose most recent transaction was much older than others but still rank high in total spending.

select customer_id,total_spent,last_transaction_days_ago,spent_rank,recency_rank
from (
select 
customer_id,total_spent,last_transaction_days_ago,
dense_rank()over(order by total_spent desc)as spent_rank,
dense_rank()over(order by last_transaction_days_ago desc )as recency_rank
from customers)t
where spent_rank <=10 and 
recency_rank <=10;
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

## 5. Compare  highest support tickets with those who raise min, and determine how their satisfaction scores differ.

select support_tickets_raised,avg(customer_satisfaction_score)as avg_satisfaction_score
from customers
group by support_tickets_raised
order by support_tickets_raised desc
limit 2;
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

## 6. Find customers whose average transaction value is consistently high even though their total number of transactions is low.

select customer_id, avg_transaction_value,total_transactions,avg_transac_rank,total_transac_rank
from (
select customer_id, avg_transaction_value,total_transactions,
dense_rank()over(order by avg_transaction_value desc)as avg_transac_rank,
dense_rank()over(order by total_transactions asc)as total_transac_rank
from customers)t
order by avg_transac_rank asc;
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

## 7. Within each app usage category, identify customers who spend significantly more than others in the same category.

select  customer_id, App_Usage_Frequency,total_spent,
round((total_spent-prv)*100/prv,2)as Prc_Less_than_prv
from (
select customer_id, App_Usage_Frequency,total_spent,
dense_rank() over (partition by App_Usage_Frequency order by total_spent desc)as Spent_rank,
coalesce(lag(total_spent) over (partition by App_Usage_Frequency),"-")as prv
from customers)
t;
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

## 8. Determine whether customers with longer tenure always have higher lifetime value, and identify exceptions.

select customer_id, active_days,ltv, tenure_rank,ltv_rank
from (
select customer_id, active_days,ltv,
dense_rank () over (order by active_days desc)as tenure_rank,
dense_rank () over (order by ltv desc)as ltv_rank
from customers)t
where tenure_rank <=20 and ltv_rank >= 100;
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

##9. Rank customers within each Income level based on avg_transaction value spend and identify the top performers.
select 1;

with transac_rank as (
select customer_id, income_level,avg_transaction_value,
dense_rank () over (partition by income_level order by avg_transaction_value desc)as Avg_transac_rank
from customers)
select customer_id, income_level,avg_transaction_value,avg_transac_rank
from transac_rank
where avg_transac_rank <=10;
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

## 10. Identify customers whose issue resolution time is worse than average but who still report high satisfaction scores.

with rnks as (
select customer_id,issue_resolution_time,customer_satisfaction_score,
dense_rank() over (order by issue_resolution_time desc)as Resoltuion_Rank,
dense_rank () over (order by customer_satisfaction_score desc)as Satisfaction_rank
from customers)
SELECT customer_id,issue_resolution_time,customer_satisfaction_score,Resoltuion_Rank,Satisfaction_rank
from rnks
where Resoltuion_Rank <=10 and Satisfaction_rank <=10;
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

##11. Find payment methods that are preferred by high-value customers and compare their average lifetime value.

select customer_id,preferred_payment_method,round(sum(ltv),2)as Total_LTV,
(select round(avg(ltv),2) from customers)as Avg_LTV
from customers
group by customer_id,preferred_payment_method
order by sum(ltv)desc
limit 10;
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

## 12. Determine which income group has the highest proportion of customers with low satisfaction scores but high spending.
select 1;

WITH ranked_customers AS (
    SELECT
        customer_id,
        income_level,
        total_spent,
        customer_satisfaction_score,
        NTILE(4) OVER (ORDER BY total_spent DESC) AS spend_quartile,
        AVG(customer_satisfaction_score) OVER () AS avg_satisfaction
    FROM customers
)
, income_summary AS (
    SELECT
        income_level,
        COUNT(*) AS total_customers,
        SUM(
            CASE
                WHEN spend_quartile = 1
                 AND customer_satisfaction_score < avg_satisfaction
                THEN 1
                ELSE 0
            END
        ) AS unhappy_high_spenders
    FROM ranked_customers
    GROUP BY income_level
)
SELECT
    income_level,
    unhappy_high_spenders,
    total_customers,
    unhappy_high_spenders / total_customers AS proportion
FROM income_summary
ORDER BY proportion DESC;
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

## 14. Identify customers who are inactive recently but historically have very high engagement and spending.
SELECT
    customer_id,
    total_spent,
    total_transactions,
    active_days,
    last_transaction_days_ago,
    inactivity_rank,
    spend_rank,
    engagement_rank
FROM (
    SELECT
        customer_id,
        total_spent,
        total_transactions,
        active_days,
        last_transaction_days_ago,
        DENSE_RANK() OVER (
            ORDER BY last_transaction_days_ago DESC
        ) AS inactivity_rank,
        DENSE_RANK() OVER (
            ORDER BY total_spent DESC
        ) AS spend_rank,
        DENSE_RANK() OVER (
            ORDER BY active_days DESC
        ) AS engagement_rank
    FROM customers
) t
WHERE inactivity_rank <= 20 
  AND spend_rank <= 20     
  AND engagement_rank <= 20; 
  -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

## 14. Compare lifetime value trends across customers with different app usage frequencies and identify which group shows the strongest performance.
select 1;

WITH ltv_summary AS (
    SELECT
        app_usage_frequency,
        COUNT(*) AS total_customers,
        AVG(ltv) AS avg_ltv,
        SUM(ltv) AS total_ltv
    FROM customers
    GROUP BY app_usage_frequency
),
top_ltv_customers AS (
    SELECT
        app_usage_frequency,
        AVG(ltv) AS avg_ltv_top_customers
    FROM (
        SELECT
            app_usage_frequency,
            ltv,
            DENSE_RANK() OVER (
                PARTITION BY app_usage_frequency
                ORDER BY ltv DESC
            ) AS ltv_rank
        FROM customers
    ) t
    WHERE ltv_rank <= 10
    GROUP BY app_usage_frequency
)
SELECT
    s.app_usage_frequency,
    s.total_customers,
    s.avg_ltv,
    s.total_ltv,
    t.avg_ltv_top_customers
FROM ltv_summary s
LEFT JOIN top_ltv_customers t
    ON s.app_usage_frequency = t.app_usage_frequency
ORDER BY s.avg_ltv DESC;


